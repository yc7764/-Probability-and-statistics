from django.apps import AppConfig


class AjaxappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ajaxapp'
