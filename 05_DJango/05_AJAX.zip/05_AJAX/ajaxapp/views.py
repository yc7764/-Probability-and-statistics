from django.shortcuts import render

# Create your views here.
def ajaxfrm(request):
    return render(request, 'ajaxapp/ajaxfrm.html')