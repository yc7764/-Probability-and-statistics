from django.urls import path
from . import views

urlpatterns = [
    path('ajaxfrm/', views.ajaxfrm, name='ajaxfrm')
]
